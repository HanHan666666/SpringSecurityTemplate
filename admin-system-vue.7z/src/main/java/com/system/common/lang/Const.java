package com.system.common.lang;

public class Const {
    public final static String CAPTCHA_KEY = "captcha";
    public static final Integer STATUS_ON = 1;
    public static final Integer STATUS_OFF = 1;

    public final static String DEFAULT_PASSWORD = "888888";
    public final static String DEFAULT_AVATAR = "https://img1.baidu.com/it/u=1811445190,4171898561&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500";
}
