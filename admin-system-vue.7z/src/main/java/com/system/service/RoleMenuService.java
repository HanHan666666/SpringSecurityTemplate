package com.system.service;

import com.system.entity.RoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 吴晗
 * @since 2023-05-18
 */
public interface RoleMenuService extends IService<RoleMenu> {

}
