package com.system.service;

import com.system.entity.Fans;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 吴晗
 * @since 2023-05-24
 */
public interface FansService extends IService<Fans> {

}
