package com.system.entity.dto;

import lombok.Data;
@Data
public class PassDTO {
    private String password;
    private String newPass;
    private String checkPass;
}
